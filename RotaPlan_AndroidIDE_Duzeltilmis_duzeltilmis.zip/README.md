# RotaPlan – Android proje

Bu ilk sürüm sadece rota işine odaklanır:

- Müşteri adı + adres ekleme
- Mevcut konumu başlangıç kabul etme
- Adresleri Android Geocoder ile koordinata çevirme
- Yaklaşık en kısa sırayı (nearest-neighbor) oluşturma
- Her müşteriye 10 dakika planlı ziyaret süresi
- Google Maps navigasyonunu açma
- “Teslim Edildi” seçilince sıradaki müşteriyi önerme
- Müşterileri telefonda kalıcı olarak saklama

## Önemli
Bu sürüm Google Maps uygulamasını navigasyon için açar; Google Maps SDK/API anahtarı gerektirmez.
Rota sıralaması cihaz üzerinde yaklaşık olarak hesaplanır. Gerçek trafik süreleri ve profesyonel çok duraklı optimizasyon için sonraki sürümde Google Routes API veya başka bir rota motoru eklenebilir.

## APK oluşturma
Android Studio'da bu klasörü açıp:
Build > Build APK(s)

ile debug APK oluşturabilirsin.
