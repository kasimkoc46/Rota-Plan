package com.rotaplan.app;

import android.Manifest;
import android.app.AlertDialog;
import android.content.*;
import android.content.pm.PackageManager;
import android.location.*;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.*;
import androidx.activity.ComponentActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.*;

public class MainActivity extends ComponentActivity {
    static final int LOC_REQ = 100;
    ArrayList<Customer> customers = new ArrayList<>();
    ArrayList<Customer> route = new ArrayList<>();
    CustomerAdapter adapter;
    TextView summary, routeInfo;
    SharedPreferences prefs;
    Location currentLocation;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        summary = findViewById(R.id.summary);
        routeInfo = findViewById(R.id.routeInfo);
        RecyclerView list = findViewById(R.id.list);
        adapter = new CustomerAdapter();
        list.setLayoutManager(new LinearLayoutManager(this));
        list.setAdapter(adapter);

        prefs = getSharedPreferences("rotaplan", MODE_PRIVATE);
        load();

        findViewById(R.id.addButton).setOnClickListener(v -> addCustomerDialog());
        findViewById(R.id.routeButton).setOnClickListener(v -> buildRoute());

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOC_REQ);
        } else getLocation();
    }

    void addCustomerDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = 24; box.setPadding(p,p,p,p);

        EditText name = new EditText(this);
        name.setHint("Müşteri adı");
        EditText address = new EditText(this);
        address.setHint("Adres");
        box.addView(name); box.addView(address);

        new AlertDialog.Builder(this)
            .setTitle("Müşteri Ekle")
            .setView(box)
            .setPositiveButton("Ekle", (d,w) -> {
                String n=name.getText().toString().trim();
                String a=address.getText().toString().trim();
                if(!n.isEmpty() && !a.isEmpty()) {
                    customers.add(new Customer(n,a));
                    save(); adapter.notifyDataSetChanged(); updateSummary();
                }
            })
            .setNegativeButton("İptal", null).show();
    }

    void buildRoute() {
        if(customers.isEmpty()) {
            toast("Önce müşteri ekle.");
            return;
        }
        Toast.makeText(this, "Adresler çözümleniyor ve en kısa yaklaşık sıra hesaplanıyor…",
                Toast.LENGTH_LONG).show();

        new Thread(() -> {
            ArrayList<Customer> pending = new ArrayList<>();
            for(Customer c: customers) {
                if(!c.delivered) {
                    if(c.lat == null) geocode(c);
                    if(c.lat != null) pending.add(c);
                }
            }
            if(pending.isEmpty()) {
                runOnUiThread(() -> {
                    route.clear(); adapter.notifyDataSetChanged();
                    routeInfo.setText("Bugünkü tüm müşteriler teslim edildi.");
                });
                return;
            }

            Location start = currentLocation;
            if(start == null) {
                start = new Location("start");
                if(pending.get(0).lat != null) {
                    start.setLatitude(pending.get(0).lat);
                    start.setLongitude(pending.get(0).lon);
                }
            }

            ArrayList<Customer> ordered = new ArrayList<>();
            double lat=start.getLatitude(), lon=start.getLongitude();

            while(!pending.isEmpty()) {
                Customer best=null; float bestDist=Float.MAX_VALUE;
                Location from=new Location("route"); from.setLatitude(lat); from.setLongitude(lon);
                for(Customer c:pending) {
                    Location to=new Location("to"); to.setLatitude(c.lat); to.setLongitude(c.lon);
                    float d=from.distanceTo(to);
                    if(d<bestDist){bestDist=d;best=c;}
                }
                ordered.add(best); pending.remove(best);
                lat=best.lat; lon=best.lon;
            }

            route.clear(); route.addAll(ordered);
            for(int i=0;i<route.size();i++) route.get(i).routeIndex=i+1;
            save();

            runOnUiThread(() -> {
                adapter.notifyDataSetChanged();
                updateSummary();
                routeInfo.setText("Rota hazır: " + route.size() +
                        " müşteri • her müşteriye 10 dk ayrıldı.");
                if(!route.isEmpty()) startNavigation(route.get(0));
            });
        }).start();
    }

    void startNavigation(Customer c) {
        Uri uri = Uri.parse("google.navigation:q=" + Uri.encode(c.address));
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        intent.setPackage("com.google.android.apps.maps");
        try { startActivity(intent); }
        catch(Exception e) {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.google.com/maps/dir/?api=1&destination=" +
                            Uri.encode(c.address))));
        }
    }

    void markDelivered(Customer c) {
        c.delivered=true;
        save(); adapter.notifyDataSetChanged(); updateSummary();

        Customer next=null;
        for(Customer x:route) if(!x.delivered){ next=x; break; }

        if(next!=null) {
            new AlertDialog.Builder(this)
                .setTitle("Teslim edildi ✓")
                .setMessage(c.name + " tamamlandı.\n\nSıradaki: " + next.name +
                        "\nPlanlanan ziyaret: 10 dakika")
                .setPositiveButton("Sonraki müşteriye git", (d,w)->startNavigation(next))
                .setNegativeButton("Kapat", null).show();
        } else {
            Toast.makeText(this,"Tüm teslimatlar tamamlandı! 🎉",Toast.LENGTH_LONG).show();
        }
    }

    void geocode(Customer c) {
        try {
            Geocoder g = new Geocoder(this, Locale.GERMANY);
            List<Address> r = g.getFromLocationName(c.address,1);
            if(r!=null && !r.isEmpty()) {
                c.lat=r.get(0).getLatitude(); c.lon=r.get(0).getLongitude();
            }
        } catch(Exception ignored) {}
    }

    void getLocation() {
        LocationManager lm=(LocationManager)getSystemService(LOCATION_SERVICE);
        try {
            if(ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)
                    ==PackageManager.PERMISSION_GRANTED) {
                Location l=lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if(l==null) l=lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                currentLocation=l;
            }
        } catch(Exception ignored){}
    }

    void updateSummary() {
        int done=0; for(Customer c:customers) if(c.delivered) done++;
        summary.setText(done + "/" + customers.size() + " teslim edildi • Ziyaret süresi: " +
                (customers.size()*10) + " dk");
    }

    void save() {
        StringBuilder s=new StringBuilder();
        for(Customer c:customers)
            s.append(c.toString()).append("\n");
        prefs.edit().putString("customers",s.toString()).apply();
    }

    void load() {
        String raw=prefs.getString("customers","");
        if(!raw.isEmpty()) {
            for(String line:raw.split("\n",-1)) {
                if(line.trim().isEmpty()) continue;
                String[] p=line.split("\\|",-1);
                if(p.length>=3) {
                    Customer c=new Customer(p[0],p[1]);
                    c.delivered=Boolean.parseBoolean(p[2]);
                    if(p.length>=5 && !p[3].isEmpty()) {
                        c.lat=Double.parseDouble(p[3]); c.lon=Double.parseDouble(p[4]);
                    }
                    customers.add(c);
                }
            }
        }
        updateSummary();
    }

    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    class Customer {
        String name,address; boolean delivered=false; Double lat,lon; int routeIndex;
        Customer(String n,String a){name=n;address=a;}
        public String toString(){return name+"|"+address+"|"+delivered+"|"+
                (lat==null?"":lat)+"|"+(lon==null?"":lon);}
    }

    class CustomerAdapter extends RecyclerView.Adapter<CustomerAdapter.VH> {
        class VH extends RecyclerView.ViewHolder {
            TextView t; Button nav,done;
            VH(LinearLayout v){super(v); t=new TextView(MainActivity.this);
                t.setTextSize(16); t.setPadding(12,12,12,8);
                v.addView(t,new LinearLayout.LayoutParams(-1,-2));
                nav=new Button(MainActivity.this); nav.setText("Navigasyon");
                done=new Button(MainActivity.this); done.setText("Teslim Edildi");
                v.addView(nav);v.addView(done);
            }
        }
        public VH onCreateViewHolder(android.view.ViewGroup p,int v){
            LinearLayout box=new LinearLayout(MainActivity.this);
            box.setOrientation(LinearLayout.VERTICAL); box.setPadding(0,8,0,12);
            return new VH(box);
        }
        public void onBindViewHolder(VH h,int pos){
            Customer c = route.size()>0 ? route.get(pos) : customers.get(pos);
            h.t.setText((c.routeIndex>0?c.routeIndex+". ":"") + c.name + "\n" +
                    c.address + "\n" + (c.delivered?"✓ TESLİM EDİLDİ":"10 dk planlı ziyaret"));
            h.nav.setOnClickListener(v->startNavigation(c));
            h.done.setEnabled(!c.delivered);
            h.done.setOnClickListener(v->markDelivered(c));
        }
        public int getItemCount(){return route.size()>0?route.size():customers.size();}
    }
}
